<?php
/****************************************************************************************
 * LiveZilla index.php
 *
 * Copyright 2014 LiveZilla GmbH
 * All rights reserved.
 * LiveZilla is a registered trademark.
 *
 ***************************************************************************************/

header('Location: ../../');

?>