<?php

header("Location: http://www.livezilla.net/apiv2/en/");
exit();

?>